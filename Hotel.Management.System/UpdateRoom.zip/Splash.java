package Hotel.Management.System;

import javax.swing.*;
import java.awt.*;

public class Splash extends JFrame {


    Splash(){
        setUndecorated(true);  // Removes the window border and title bar
        setBackground(new Color(0, 0, 0, 0));
        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/splash.gif"));
        JLabel label = new JLabel(imageIcon);
        label.setBounds(0,0,858,680);
        add(label);

        setUndecorated(true);
        setLayout(null);
        setLocation(220,60);
        setSize(700,900);
        setVisible(true);

        try {
            Thread.sleep(4000);
            new Login();
            setVisible(false);

        }catch (Exception e){
            e.printStackTrace();
        }


    }
    public static void main(String[] args) {
        new Splash();


    }
}
